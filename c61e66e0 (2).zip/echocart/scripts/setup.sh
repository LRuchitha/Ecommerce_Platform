#!/bin/bash

echo "🚀 Setting up EchoCart development environment..."

# Check prerequisites
command -v java >/dev/null 2>&1 || { echo "❌ Java 17+ is required but not installed."; exit 1; }
command -v node >/dev/null 2>&1 || { echo "❌ Node.js 18+ is required but not installed."; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "❌ Docker is required but not installed."; exit 1; }

echo "✅ Prerequisites check passed"

# Setup backend
echo "🔧 Setting up backend..."
cd backend
cp ../application-dev.yml src/main/resources/
echo "✅ Backend configuration ready"

# Setup frontend  
echo "🔧 Setting up frontend..."
cd ../frontend
cp .env.example .env
npm install
echo "✅ Frontend dependencies installed"

# Start database
echo "🗄️ Starting database..."
cd ..
docker-compose up -d postgres redis
echo "✅ Database services started"

echo ""
echo "🎉 EchoCart setup complete!"
echo ""
echo "Next steps:"
echo "1. Start backend: cd backend && ./mvnw spring-boot:run"
echo "2. Start frontend: cd frontend && npm run dev"
echo "3. Open http://localhost:5173"
echo ""
echo "Test credentials:"
echo "📱 Phone: 9876543210 (OTP: 123456)"
echo "📧 Email: test@echocart.com / Password: Test123!"
