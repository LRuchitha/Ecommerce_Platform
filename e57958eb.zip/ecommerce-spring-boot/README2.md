# E-Commerce Spring Boot Application

A complete e-commerce web application built with Spring Boot 3.x, Java 21, MySQL 8.0, Spring Security 6, Thymeleaf, and Bootstrap 5.

## Required Software

- **Java 21** (JDK, not just JRE)
- **Maven 3.6+**
- **MySQL 8.0.x** 
- **IntelliJ IDEA Community Edition** (recommended)
- **MySQL Workbench 8.0.x** (for database management)
- **Git** (optional, for version control)

## Features

✅ User Registration and Login (Session-based authentication)
✅ Product Catalog with Search and Categories  
✅ Shopping Cart Management
✅ Order Processing and History
✅ User Profile Management
✅ Responsive Bootstrap 5 UI
✅ INR Currency Support (₹)
✅ Image Management for Products
✅ BCrypt Password Encryption
✅ CSRF Protection

## Setup Instructions

### 1. Database Setup

1. **Install MySQL 8.0** if not already installed
2. **Start MySQL Server**
3. **Create Database** (Optional - app will auto-create):
   ```sql
   CREATE DATABASE ecommerce_db;
   ```

### 2. Project Configuration

1. **Clone/Extract** the project to your desired location
2. **Configure Database Connection** in `src/main/resources/application.properties`:
   ```properties
   spring.datasource.username=YOUR_MYSQL_USERNAME
   spring.datasource.password=YOUR_MYSQL_PASSWORD
   ```
3. **Verify MySQL is running** on port 3306

### 3. Running the Application

#### Option A: Using IntelliJ IDEA
1. Open IntelliJ IDEA Community Edition
2. Choose "Open" and select the project folder
3. Wait for Maven to download dependencies
4. Right-click `EcommerceApplication.java` and select "Run"

#### Option B: Using Command Line
```bash
cd project-directory
mvn clean install
mvn spring-boot:run
```

### 4. Access the Application

- **Application URL**: http://localhost:8080
- **Login Credentials**:
  - Username: `customer1`, Password: `customer123`  
  - Username: `customer2`, Password: `customer123`

## Application URLs

- **Home/Products**: http://localhost:8080/
- **Login**: http://localhost:8080/login
- **Register**: http://localhost:8080/register
- **Cart**: http://localhost:8080/cart (requires login)
- **Orders**: http://localhost:8080/orders (requires login)
- **Profile**: http://localhost:8080/profile (requires login)

## Project Structure

```
src/main/java/com/ecommerce/
├── EcommerceApplication.java           # Main Spring Boot application
├── config/
│   └── SecurityConfig.java            # Spring Security configuration
├── controller/
│   ├── AuthController.java            # Login/Register endpoints
│   ├── ProductController.java         # Product catalog endpoints
│   ├── CartController.java            # Shopping cart endpoints
│   ├── OrderController.java           # Order processing endpoints
│   └── UserController.java            # User profile endpoints
├── service/
│   ├── UserService.java               # User management services
│   ├── ProductService.java            # Product catalog services
│   ├── CartService.java               # Shopping cart services
│   └── OrderService.java              # Order processing services
├── repository/
│   ├── UserRepository.java            # User data access
│   ├── ProductRepository.java         # Product data access
│   ├── CartItemRepository.java        # Cart data access
│   ├── OrderRepository.java           # Order data access
│   └── OrderItemRepository.java       # Order items data access
├── model/
│   ├── User.java                      # User entity
│   ├── Product.java                   # Product entity
│   ├── CartItem.java                  # Cart item entity
│   ├── Order.java                     # Order entity
│   └── OrderItem.java                 # Order item entity
├── dto/
│   ├── UserRegistrationDto.java       # Registration form data
│   └── UserProfileDto.java            # Profile update form data
└── bootstrap/
    └── DataLoader.java                # Initial data seeding

src/main/resources/
├── application.properties             # Application configuration
├── templates/                         # Thymeleaf templates
│   ├── layout.html                   # Main layout template
│   ├── fragments/
│   │   ├── header.html               # Navigation header
│   │   └── footer.html               # Footer component
│   ├── auth/
│   │   ├── login.html                # Login page
│   │   └── register.html             # Registration page
│   ├── product/
│   │   ├── list.html                 # Product catalog
│   │   └── detail.html               # Product details
│   ├── cart/
│   │   └── view.html                 # Shopping cart
│   ├── order/
│   │   ├── checkout.html             # Checkout page
│   │   ├── confirmation.html         # Order confirmation
│   │   └── history.html              # Order history
│   └── user/
│       └── profile.html              # User profile
└── static/
    ├── css/
    │   └── style.css                 # Custom styles
    ├── js/
    │   └── app.js                    # Custom JavaScript
    └── images/
        ├── product-01.jpg            # Product images
        ├── product-02.jpg
        └── ... (10+ product images)
```

## Troubleshooting

### Common Issues

**1. MySQL Connection Issues**
```
Error: Access denied for user...
```
**Solution**: Check username/password in `application.properties`, ensure MySQL is running

**2. Java Version Issues**  
```
Error: release version 21 not supported
```
**Solution**: Ensure you have Java 21 JDK (not JRE) installed and `JAVA_HOME` is set correctly

**3. Port Already in Use**
```
Error: Port 8080 already in use
```
**Solution**: Change server port in `application.properties`:
```properties
server.port=8081
```

**4. Database Schema Issues**
**Solution**: Set `spring.jpa.hibernate.ddl-auto=create` for fresh start (will delete existing data)

**5. Missing Lombok**
**Solution**: Install Lombok plugin in IntelliJ IDEA:
- Go to File → Settings → Plugins
- Search for "Lombok" and install
- Enable annotation processing: Settings → Compiler → Annotation Processors → Enable

### MySQL Authentication Issues

If you encounter authentication issues with MySQL 8.0:
```sql
ALTER USER 'your_username'@'localhost' IDENTIFIED WITH mysql_native_password BY 'your_password';
FLUSH PRIVILEGES;
```

## Customization

### Adding New Products
1. Add product images to `src/main/resources/static/images/`
2. Update `DataLoader.java` with new product data
3. Restart application

### Changing Seed Data
Edit the `DataLoader.java` file to modify:
- Predefined users
- Initial product catalog
- Sample orders (if needed)

### UI Customization
- **Colors/Themes**: Edit `src/main/resources/static/css/style.css`
- **Layout**: Modify `src/main/resources/templates/layout.html`
- **Components**: Update individual templates in `templates/` folder

### Production Configuration
For production deployment:
```properties
# Change to validate to prevent schema changes
spring.jpa.hibernate.ddl-auto=validate
# Disable SQL logging  
spring.jpa.show-sql=false
# Enable Thymeleaf caching
spring.thymeleaf.cache=true
# Set production database URL
spring.datasource.url=jdbc:mysql://production-server:3306/ecommerce_db
```

## Security Features

- ✅ **BCrypt Password Encoding**
- ✅ **Session-based Authentication** 
- ✅ **CSRF Protection**
- ✅ **SQL Injection Prevention** (JPA/Hibernate)
- ✅ **XSS Protection** (Thymeleaf escaping)
- ✅ **Secure Headers** (Spring Security defaults)

## Currency Format

All prices are displayed in Indian Rupees (₹) with proper formatting:
- ₹79,999 (for amounts >= ₹1,000)
- ₹999 (for amounts < ₹1,000)

## Support

For issues or questions:
1. Check this README first
2. Verify all software versions match requirements  
3. Check application logs in console/terminal
4. Ensure MySQL is running and accessible
5. Verify Java 21 JDK is properly installed

## License

This project is for educational and demonstration purposes.
