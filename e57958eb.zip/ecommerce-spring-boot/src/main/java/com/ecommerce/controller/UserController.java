package com.ecommerce.controller;

import com.ecommerce.dto.UserProfileDto;
import com.ecommerce.model.User;
import com.ecommerce.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping("/profile")
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final UserService userService;

    @GetMapping
    public String profilePage(Authentication authentication, Model model) {
        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        UserProfileDto profileDto = UserProfileDto.builder()
                .name(user.getName())
                .phone(user.getPhone())
                .address(user.getAddress())
                .email(user.getEmail())
                .build();

        model.addAttribute("user", user);
        model.addAttribute("userProfile", profileDto);

        return "user/profile";
    }

    @PostMapping
    public String updateProfile(@Valid @ModelAttribute("userProfile") UserProfileDto profileDto,
                              BindingResult result,
                              Authentication authentication,
                              Model model,
                              RedirectAttributes redirectAttributes) {

        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "user/profile";
        }

        try {
            userService.updateProfile(user, profileDto);
            redirectAttributes.addFlashAttribute("message", 
                "Profile updated successfully!");
        } catch (Exception e) {
            log.error("Error updating profile for user {}", user.getUsername(), e);
            model.addAttribute("user", user);
            model.addAttribute("error", "Failed to update profile. Please try again.");
            return "user/profile";
        }

        return "redirect:/profile";
    }

    private User getCurrentUser(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }

        Optional<User> userOpt = userService.findByUsername(authentication.getName());
        return userOpt.orElse(null);
    }
}