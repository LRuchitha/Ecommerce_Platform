package com.ecommerce.controller;

import com.ecommerce.model.Order;
import com.ecommerce.model.User;
import com.ecommerce.service.CartService;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/orders")
@RequiredArgsConstructor
@Slf4j
public class OrderController {

    private final OrderService orderService;
    private final CartService cartService;
    private final UserService userService;

    @GetMapping("/checkout")
    public String checkoutPage(Authentication authentication, Model model) {
        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        // Check if cart is empty
        int cartItemCount = cartService.getCartItemCount(user);
        if (cartItemCount == 0) {
            return "redirect:/cart?error=Cart is empty";
        }

        BigDecimal cartTotal = cartService.getCartTotal(user);

        model.addAttribute("user", user);
        model.addAttribute("cartTotal", cartTotal);
        model.addAttribute("cartItemCount", cartItemCount);

        return "order/checkout";
    }

    @PostMapping("/place-order")
    public String placeOrder(Authentication authentication, 
                           RedirectAttributes redirectAttributes) {

        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        try {
            Order order = orderService.createOrderFromCart(user);
            redirectAttributes.addFlashAttribute("message", 
                "Order placed successfully! Order ID: " + order.getId());
            return "redirect:/orders/" + order.getId();
        } catch (Exception e) {
            log.error("Error placing order for user {}", user.getUsername(), e);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/orders/checkout";
        }
    }

    @GetMapping
    public String orderHistory(Authentication authentication, Model model) {
        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        List<Order> orders = orderService.getUserOrders(user);
        model.addAttribute("orders", orders);

        return "order/history";
    }

    @GetMapping("/{orderId}")
    public String orderDetail(@PathVariable Long orderId, 
                            Authentication authentication, 
                            Model model) {

        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        Optional<Order> orderOpt = orderService.getUserOrderById(user, orderId);
        if (orderOpt.isEmpty()) {
            return "redirect:/orders?error=Order not found";
        }

        model.addAttribute("order", orderOpt.get());
        return "order/detail";
    }

    @PostMapping("/{orderId}/cancel")
    public String cancelOrder(@PathVariable Long orderId,
                            Authentication authentication,
                            RedirectAttributes redirectAttributes) {

        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        try {
            orderService.cancelOrder(user, orderId);
            redirectAttributes.addFlashAttribute("message", 
                "Order cancelled successfully!");
        } catch (Exception e) {
            log.error("Error cancelling order {} for user {}", orderId, user.getUsername(), e);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/orders/" + orderId;
    }

    private User getCurrentUser(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }

        Optional<User> userOpt = userService.findByUsername(authentication.getName());
        return userOpt.orElse(null);
    }
}