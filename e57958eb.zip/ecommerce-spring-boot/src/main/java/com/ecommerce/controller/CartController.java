package com.ecommerce.controller;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.User;
import com.ecommerce.service.CartService;
import com.ecommerce.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/cart")
@RequiredArgsConstructor
@Slf4j
public class CartController {

    private final CartService cartService;
    private final UserService userService;

    @GetMapping
    public String viewCart(Authentication authentication, Model model) {
        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        List<CartItem> cartItems = cartService.getCartItems(user);
        BigDecimal cartTotal = cartService.getCartTotal(user);

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("cartTotal", cartTotal);
        model.addAttribute("cartItemCount", cartItems.size());

        return "cart/view";
    }

    @PostMapping("/add/{productId}")
    public String addToCart(@PathVariable Long productId,
                          @RequestParam(defaultValue = "1") int quantity,
                          Authentication authentication,
                          RedirectAttributes redirectAttributes) {

        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        try {
            cartService.addToCart(user, productId, quantity);
            redirectAttributes.addFlashAttribute("message", 
                quantity + " item(s) added to cart successfully!");
        } catch (Exception e) {
            log.error("Error adding product {} to cart for user {}", productId, user.getUsername(), e);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/products/" + productId;
    }

    @PostMapping("/update/{cartItemId}")
    public String updateCartItem(@PathVariable Long cartItemId,
                               @RequestParam int quantity,
                               Authentication authentication,
                               RedirectAttributes redirectAttributes) {

        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        try {
            cartService.updateCartItemQuantity(user, cartItemId, quantity);
            if (quantity > 0) {
                redirectAttributes.addFlashAttribute("message", "Cart updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("message", "Item removed from cart!");
            }
        } catch (Exception e) {
            log.error("Error updating cart item {} for user {}", cartItemId, user.getUsername(), e);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/cart";
    }

    @PostMapping("/remove/{cartItemId}")
    public String removeCartItem(@PathVariable Long cartItemId,
                               Authentication authentication,
                               RedirectAttributes redirectAttributes) {

        User user = getCurrentUser(authentication);
        if (user == null) {
            return "redirect:/login";
        }

        try {
            cartService.removeCartItem(user, cartItemId);
            redirectAttributes.addFlashAttribute("message", "Item removed from cart successfully!");
        } catch (Exception e) {
            log.error("Error removing cart item {} for user {}", cartItemId, user.getUsername(), e);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/cart";
    }

    private User getCurrentUser(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }

        Optional<User> userOpt = userService.findByUsername(authentication.getName());
        return userOpt.orElse(null);
    }
}