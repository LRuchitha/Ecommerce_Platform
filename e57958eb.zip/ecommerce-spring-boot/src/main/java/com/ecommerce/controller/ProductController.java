package com.ecommerce.controller;

import com.ecommerce.model.Product;
import com.ecommerce.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @GetMapping("/")
    public String homePage(Model model) {
        return "redirect:/products";
    }

    @GetMapping("/products")
    public String productList(@RequestParam(defaultValue = "") String search,
                             @RequestParam(defaultValue = "") String category,
                             @RequestParam(defaultValue = "0") int page,
                             @RequestParam(defaultValue = "12") int size,
                             Model model) {

        Pageable pageable = PageRequest.of(page, size);
        Page<Product> productPage;

        if (!search.isEmpty()) {
            productPage = productService.searchProducts(search, pageable);
            model.addAttribute("search", search);
        } else if (!category.isEmpty()) {
            List<Product> categoryProducts = productService.getProductsByCategory(category);
            // For simplicity, convert to page-like structure
            int start = page * size;
            int end = Math.min(start + size, categoryProducts.size());
            List<Product> pageContent = categoryProducts.subList(start, end);
            model.addAttribute("products", pageContent);
            model.addAttribute("selectedCategory", category);
        } else {
            productPage = productService.searchProducts("", pageable);
        }

        if (!category.isEmpty()) {
            // Handle category filtering without pagination for simplicity
            List<Product> allProducts = productService.getProductsByCategory(category);
            model.addAttribute("products", allProducts);
        } else {
            model.addAttribute("products", productPage.getContent());
            model.addAttribute("currentPage", page);
            model.addAttribute("totalPages", productPage.getTotalPages());
            model.addAttribute("totalElements", productPage.getTotalElements());
        }

        // Add categories for filter dropdown
        List<String> categories = productService.getAllCategories();
        model.addAttribute("categories", categories);

        return "product/list";
    }

    @GetMapping("/products/{id}")
    public String productDetail(@PathVariable Long id, Model model) {
        Optional<Product> productOpt = productService.getProductById(id);
        if (productOpt.isEmpty()) {
            return "redirect:/products?error=Product not found";
        }

        model.addAttribute("product", productOpt.get());
        return "product/detail";
    }
}