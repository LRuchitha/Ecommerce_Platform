package com.ecommerce.service;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.Product;
import com.ecommerce.model.User;
import com.ecommerce.repository.CartItemRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class CartService {

    private final CartItemRepository cartItemRepository;
    private final ProductService productService;

    @Transactional(readOnly = true)
    public List<CartItem> getCartItems(User user) {
        return cartItemRepository.findByUserOrderByIdDesc(user);
    }

    @Transactional(readOnly = true)
    public int getCartItemCount(User user) {
        return cartItemRepository.countByUser(user);
    }

    @Transactional
    public CartItem addToCart(User user, Long productId, int quantity) {
        Optional<Product> productOpt = productService.getProductById(productId);
        if (productOpt.isEmpty()) {
            throw new RuntimeException("Product not found: " + productId);
        }

        Product product = productOpt.get();
        if (product.getStockQty() < quantity) {
            throw new RuntimeException("Insufficient stock. Available: " + product.getStockQty());
        }

        Optional<CartItem> existingItemOpt = cartItemRepository.findByUserAndProduct(user, product);

        CartItem cartItem;
        if (existingItemOpt.isPresent()) {
            cartItem = existingItemOpt.get();
            int newQuantity = cartItem.getQuantity() + quantity;

            if (product.getStockQty() < newQuantity) {
                throw new RuntimeException("Insufficient stock. Available: " + product.getStockQty() + 
                                         ", In cart: " + cartItem.getQuantity());
            }

            cartItem.setQuantity(newQuantity);
        } else {
            cartItem = CartItem.builder()
                    .user(user)
                    .product(product)
                    .quantity(quantity)
                    .build();
        }

        CartItem savedItem = cartItemRepository.save(cartItem);
        log.info("Added {} units of product {} to cart for user {}", 
                quantity, productId, user.getUsername());
        return savedItem;
    }

    @Transactional
    public CartItem updateCartItemQuantity(User user, Long cartItemId, int quantity) {
        CartItem cartItem = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Cart item not found: " + cartItemId));

        if (!cartItem.getUser().getUserId().equals(user.getUserId())) {
            throw new RuntimeException("Access denied to cart item: " + cartItemId);
        }

        if (quantity <= 0) {
            cartItemRepository.delete(cartItem);
            log.info("Removed cart item {} for user {}", cartItemId, user.getUsername());
            return null;
        }

        Product product = cartItem.getProduct();
        if (product.getStockQty() < quantity) {
            throw new RuntimeException("Insufficient stock. Available: " + product.getStockQty());
        }

        cartItem.setQuantity(quantity);
        CartItem updatedItem = cartItemRepository.save(cartItem);
        log.info("Updated cart item {} quantity to {} for user {}", 
                cartItemId, quantity, user.getUsername());
        return updatedItem;
    }

    @Transactional
    public void removeCartItem(User user, Long cartItemId) {
        CartItem cartItem = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Cart item not found: " + cartItemId));

        if (!cartItem.getUser().getUserId().equals(user.getUserId())) {
            throw new RuntimeException("Access denied to cart item: " + cartItemId);
        }

        cartItemRepository.delete(cartItem);
        log.info("Removed cart item {} for user {}", cartItemId, user.getUsername());
    }

    @Transactional(readOnly = true)
    public BigDecimal getCartTotal(User user) {
        List<CartItem> cartItems = getCartItems(user);
        return cartItems.stream()
                .map(item -> item.getProduct().getPrice()
                        .multiply(BigDecimal.valueOf(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Transactional
    public void clearCart(User user) {
        cartItemRepository.deleteByUser(user);
        log.info("Cleared cart for user {}", user.getUsername());
    }
}