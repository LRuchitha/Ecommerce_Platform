package com.ecommerce.bootstrap;

import com.ecommerce.model.Product;
import com.ecommerce.model.User;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        loadUsers();
        loadProducts();
    }

    private void loadUsers() {
        if (userRepository.count() == 0) {
            log.info("Loading seed users...");

            List<User> users = Arrays.asList(
                User.builder()
                    .username("customer1")
                    .password(passwordEncoder.encode("customer123"))
                    .name("John Doe")
                    .phone("9876543210")
                    .address("123 Main St, Mumbai, India")
                    .email("john.doe@example.com")
                    .role(User.Role.CUSTOMER)
                    .build(),

                User.builder()
                    .username("customer2")
                    .password(passwordEncoder.encode("customer123"))
                    .name("Jane Smith")
                    .phone("8765432109")
                    .address("456 Oak Ave, Delhi, India")
                    .email("jane.smith@example.com")
                    .role(User.Role.CUSTOMER)
                    .build()
            );

            userRepository.saveAll(users);
            log.info("Loaded {} users", users.size());
        }
    }

    private void loadProducts() {
        if (productRepository.count() == 0) {
            log.info("Loading seed products...");

            List<Product> products = Arrays.asList(
                Product.builder()
                    .name("Samsung Galaxy S24")
                    .description("Latest flagship smartphone with advanced camera and powerful processor")
                    .category("Electronics")
                    .price(new BigDecimal("79999"))
                    .stockQty(50)
                    .imageUrl("/images/samsung-galaxy.jpg")
                    .build(),

                Product.builder()
                    .name("Apple iPhone 15")
                    .description("Premium smartphone with A17 chip and enhanced camera system")
                    .category("Electronics")
                    .price(new BigDecimal("89999"))
                    .stockQty(30)
                    .imageUrl("/images/iphone-15.jpg")
                    .build(),

                Product.builder()
                    .name("Sony WH-1000XM5")
                    .description("Wireless noise cancelling headphones with premium sound quality")
                    .category("Electronics")
                    .price(new BigDecimal("29999"))
                    .stockQty(25)
                    .imageUrl("/images/sony-headphones.jpg")
                    .build(),

                Product.builder()
                    .name("Dell XPS 13")
                    .description("Ultrabook laptop for professionals with Intel Core i7 processor")
                    .category("Computers")
                    .price(new BigDecimal("119999"))
                    .stockQty(15)
                    .imageUrl("/images/dell-xps.jpg")
                    .build(),

                Product.builder()
                    .name("Nike Air Force 1")
                    .description("Classic white sneakers with comfortable cushioning")
                    .category("Footwear")
                    .price(new BigDecimal("8999"))
                    .stockQty(100)
                    .imageUrl("/images/nike-shoes.jpg")
                    .build(),

                Product.builder()
                    .name("Adidas Ultraboost 22")
                    .description("Premium running shoes with Boost technology")
                    .category("Footwear")
                    .price(new BigDecimal("12999"))
                    .stockQty(75)
                    .imageUrl("/images/adidas-shoes.jpg")
                    .build(),

                Product.builder()
                    .name("Levi's 501 Jeans")
                    .description("Classic straight fit denim jeans in premium quality")
                    .category("Clothing")
                    .price(new BigDecimal("4499"))
                    .stockQty(200)
                    .imageUrl("/images/levis-jeans.jpg")
                    .build(),

                Product.builder()
                    .name("Apple Watch Series 9")
                    .description("Smartwatch with health monitoring and fitness tracking")
                    .category("Electronics")
                    .price(new BigDecimal("41999"))
                    .stockQty(40)
                    .imageUrl("/images/apple-watch.jpg")
                    .build(),

                Product.builder()
                    .name("Ray-Ban Aviator")
                    .description("Classic aviator sunglasses with UV protection")
                    .category("Accessories")
                    .price(new BigDecimal("12999"))
                    .stockQty(60)
                    .imageUrl("/images/rayban-aviator.jpg")
                    .build(),

                Product.builder()
                    .name("JBL Flip 6")
                    .description("Portable waterproof Bluetooth speaker with powerful bass")
                    .category("Electronics")
                    .price(new BigDecimal("11999"))
                    .stockQty(80)
                    .imageUrl("/images/jbl-speaker.jpg")
                    .build(),

                Product.builder()
                    .name("Puma T-Shirt")
                    .description("Cotton sports t-shirt with moisture-wicking technology")
                    .category("Clothing")
                    .price(new BigDecimal("1999"))
                    .stockQty(150)
                    .imageUrl("/images/puma-tshirt.jpg")
                    .build(),

                Product.builder()
                    .name("Fossil Watch")
                    .description("Analog watch with leather strap and water resistance")
                    .category("Accessories")
                    .price(new BigDecimal("8999"))
                    .stockQty(35)
                    .imageUrl("/images/fossil-watch.jpg")
                    .build()
            );

            productRepository.saveAll(products);
            log.info("Loaded {} products", products.size());
        }
    }
}