// E-Store JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Update cart count on page load
    updateCartCount();

    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Format currency inputs
    formatCurrencyElements();

    // Add loading states to forms
    initializeFormLoading();

    // Initialize quantity controls
    initializeQuantityControls();
});

// Update cart count (this would typically be done server-side or via AJAX)
function updateCartCount() {
    // In a real application, this would fetch the cart count from the server
    // For now, we'll just ensure the badge is visible if there are items
    const cartBadge = document.getElementById('cart-count');
    if (cartBadge) {
        // This would be set by the server in the template
        const count = cartBadge.textContent;
        if (count && count !== '0') {
            cartBadge.style.display = 'inline-block';
        } else {
            cartBadge.style.display = 'none';
        }
    }
}

// Format currency elements
function formatCurrencyElements() {
    document.querySelectorAll('.price, .currency').forEach(element => {
        const text = element.textContent;
        if (text.includes('₹')) {
            element.classList.add('text-rupee');
        }
    });
}

// Initialize form loading states
function initializeFormLoading() {
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="bi bi-arrow-repeat"></i> Processing...';

                // Re-enable button after 10 seconds as fallback
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }, 10000);
            }
        });
    });
}

// Initialize quantity controls
function initializeQuantityControls() {
    document.querySelectorAll('input[type="number"][name="quantity"]').forEach(input => {
        input.addEventListener('change', function() {
            const value = parseInt(this.value);
            const min = parseInt(this.getAttribute('min')) || 1;
            const max = parseInt(this.getAttribute('max')) || 999;

            if (value < min) {
                this.value = min;
            } else if (value > max) {
                this.value = max;
                alert(`Maximum quantity available is ${max}`);
            }
        });
    });
}

// Utility functions
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;

    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);

        // Auto dismiss after 5 seconds
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
}

function formatPrice(amount) {
    return '₹' + new Intl.NumberFormat('en-IN').format(amount);
}

function confirmAction(message) {
    return confirm(message);
}

// Search functionality enhancement
function initializeSearch() {
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                // In a real application, this could trigger AJAX search
                console.log('Searching for:', this.value);
            }, 300);
        });
    }
}

// Image lazy loading and error handling
function initializeImageHandling() {
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('error', function() {
            this.src = '/images/placeholder.jpg';
            this.alt = 'Image not available';
        });

        // Add loading animation
        img.addEventListener('load', function() {
            this.classList.add('fade-in');
        });
    });
}

// Initialize all features
document.addEventListener('DOMContentLoaded', function() {
    initializeSearch();
    initializeImageHandling();
});

// Export functions for global use
window.EStore = {
    showAlert,
    formatPrice,
    confirmAction,
    updateCartCount
};