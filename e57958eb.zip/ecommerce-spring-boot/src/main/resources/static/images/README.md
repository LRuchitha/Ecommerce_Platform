# Product Images

This directory should contain product images referenced in the DataLoader.java file.

Required images:
- samsung-galaxy.jpg
- iphone-15.jpg  
- sony-headphones.jpg
- dell-xps.jpg
- nike-shoes.jpg
- adidas-shoes.jpg
- levis-jeans.jpg
- apple-watch.jpg
- rayban-aviator.jpg
- jbl-speaker.jpg
- puma-tshirt.jpg
- fossil-watch.jpg
- placeholder.jpg (default image for missing products)

You can replace these with actual product images or use the generated images from the demo.
Images should be sized appropriately for web display (recommended: 400x400px to 800x800px).
