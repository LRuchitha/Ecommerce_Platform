# EchoCart - E-Commerce Platform

A full-stack e-commerce web application built with Spring Boot, MySQL, and Thymeleaf.

## Features

- **User Authentication**: Secure registration and login with BCrypt password hashing
- **Multi-field Login**: Login using username, email, or phone number
- **Product Catalog**: Browse products by categories with search functionality
- **Shopping Cart**: Add, update, and remove items from cart
- **Wishlist**: Save products for later purchase
- **Order Management**: Place orders and track order history
- **Payment Integration**: Support for Stripe payments and Cash on Delivery (COD)
- **Responsive Design**: Mobile-friendly UI with Bootstrap
- **Animated UI**: Beautiful animations and micro-interactions
- **Admin Features**: Product and category management (admin users)

## Technology Stack

- **Backend**: Spring Boot 3.2.0, Spring Security, Spring Data JPA
- **Frontend**: Thymeleaf, Bootstrap 5, JavaScript
- **Database**: MySQL 8.0+
- **Payment**: Stripe API (optional)
- **Build Tool**: Maven
- **Java Version**: 21

## Getting Started

### Prerequisites

- Java 21 or higher
- Maven 3.6+
- MySQL 8.0+
- MySQL Workbench (recommended)
- IntelliJ IDEA Community Edition (recommended)

### Installation

1. **Clone or extract the project**
   ```bash
   cd echocart
   ```

2. **Set up MySQL database**
   - Open MySQL Workbench
   - Run the following SQL commands:
   ```sql
   CREATE DATABASE IF NOT EXISTS echocart
     CHARACTER SET utf8mb4
     COLLATE utf8mb4_0900_ai_ci;

   CREATE USER IF NOT EXISTS 'echocart_user'@'localhost' IDENTIFIED BY 'StrongPassword!123';
   GRANT ALL PRIVILEGES ON echocart.* TO 'echocart_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. **Configure application properties**
   - Update `src/main/resources/application.properties` with your database credentials
   - Optionally add your Stripe API keys for payment processing

4. **Run the application**
   ```bash
   mvn spring-boot:run
   ```
   Or open in IntelliJ IDEA and run the `EchoCartApplication` class.

5. **Access the application**
   - Open your browser and navigate to `http://localhost:8080`
   - The application will automatically create sample data on first run

## Default Users

The application creates two default users:

1. **Demo Customer**
   - Username: `demo`
   - Email: `demo@echocart.test`
   - Phone: `9999999999`
   - Password: `Demo@123`

2. **Admin User**
   - Username: `admin`
   - Email: `admin@echocart.test`
   - Phone: `8888888888`
   - Password: `Admin@123`

## Project Structure

```
echocart/
├── src/
│   ├── main/
│   │   ├── java/com/echocart/app/
│   │   │   ├── config/           # Configuration classes
│   │   │   ├── controller/       # Web controllers
│   │   │   ├── dto/             # Data Transfer Objects
│   │   │   ├── entity/          # JPA entities
│   │   │   ├── repository/      # Data repositories
│   │   │   ├── service/         # Business logic
│   │   │   ├── util/            # Utility classes
│   │   │   └── EchoCartApplication.java
│   │   └── resources/
│   │       ├── templates/       # Thymeleaf templates
│   │       ├── static/          # CSS, JS, images
│   │       └── application.properties
│   └── test/                    # Test files
├── pom.xml
├── README.md
└── reamme1 (setup guide)
```

## Configuration

### Database Configuration
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/echocart?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=echocart_user
spring.datasource.password=StrongPassword!123
```

### Stripe Configuration (Optional)
```properties
stripe.api.key=your_stripe_secret_key
stripe.public.key=your_stripe_publishable_key
stripe.currency=INR
```

If Stripe keys are not provided, only Cash on Delivery (COD) will be available.

## Features Overview

### Authentication
- Multi-field login (username/email/phone)
- Secure password hashing with BCrypt
- Session-based authentication with Spring Security
- Auto-login after registration

### Product Management
- Category-based product organization
- Product search and filtering
- Featured products on homepage
- Product detail pages with images
- Stock management

### Shopping Experience
- Shopping cart with quantity management
- Wishlist functionality
- Order placement with address management
- Order history and tracking
- Payment processing (Stripe + COD)

### Admin Features
- Category management
- Product CRUD operations
- Order management
- User management

## API Endpoints

### Authentication
- `GET /login` - Login page
- `POST /login` - Process login
- `GET /register` - Registration page
- `POST /register` - Process registration
- `POST /logout` - Logout

### Public Endpoints
- `GET /` - Homepage
- `GET /category/{slug}` - Category products
- `GET /product/{slug}` - Product details
- `GET /search` - Product search

### Protected Endpoints
- `GET /cart` - View cart
- `POST /cart/add` - Add to cart
- `GET /orders` - Order history
- `GET /profile` - User profile

## Testing

### Test Stripe Payments
Use these test card numbers:
- Success: `4242 4242 4242 4242`
- Declined: `4000 0000 0000 0002`
- Use any future expiry date, any 3-digit CVC, and any ZIP code

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support or questions, please open an issue in the repository or contact the development team.

---

**EchoCart** - Your trusted e-commerce platform built with modern technologies.
