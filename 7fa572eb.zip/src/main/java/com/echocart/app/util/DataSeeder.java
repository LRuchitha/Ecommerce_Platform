package com.echocart.app.util;

import com.echocart.app.entity.*;
import com.echocart.app.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataSeeder.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        seedUsers();
        seedCategories();
        seedProducts();
        logger.info("Data seeding completed successfully!");
    }

    private void seedUsers() {
        if (userRepository.count() == 0) {
            // Create demo user
            User demoUser = new User();
            demoUser.setFullName("Demo User");
            demoUser.setUsername("demo");
            demoUser.setEmail("demo@echocart.test");
            demoUser.setPhoneNumber("9999999999");
            demoUser.setPasswordHash(passwordEncoder.encode("Demo@123"));
            demoUser.setRole(User.Role.CUSTOMER);
            demoUser.setEnabled(true);

            userRepository.save(demoUser);

            // Create admin user
            User adminUser = new User();
            adminUser.setFullName("Admin User");
            adminUser.setUsername("admin");
            adminUser.setEmail("admin@echocart.test");
            adminUser.setPhoneNumber("8888888888");
            adminUser.setPasswordHash(passwordEncoder.encode("Admin@123"));
            adminUser.setRole(User.Role.ADMIN);
            adminUser.setEnabled(true);

            userRepository.save(adminUser);

            logger.info("Demo users created successfully!");
        }
    }

    private void seedCategories() {
        if (categoryRepository.count() == 0) {
            List<Category> categories = Arrays.asList(
                new Category("Electronics", "electronics", "Latest gadgets and electronic devices"),
                new Category("Fashion", "fashion", "Trendy clothing and accessories"),
                new Category("Home & Kitchen", "home-kitchen", "Home appliances and kitchen essentials"),
                new Category("Beauty & Health", "beauty-health", "Beauty products and health supplements"),
                new Category("Sports & Fitness", "sports-fitness", "Sports equipment and fitness gear"),
                new Category("Books & Media", "books-media", "Books, movies, and digital media"),
                new Category("Toys & Games", "toys-games", "Toys and games for all ages")
            );

            categoryRepository.saveAll(categories);
            logger.info("Categories created successfully!");
        }
    }

    private void seedProducts() {
        if (productRepository.count() == 0) {
            List<Category> categories = categoryRepository.findAll();

            // Electronics products
            Category electronics = findCategoryBySlug(categories, "electronics");
            if (electronics != null) {
                createProduct(electronics, "Smartphone Pro Max", "smartphone-pro-max", 
                    "Latest flagship smartphone with advanced features", new BigDecimal("79999"), 25, 
                    "/images/products/smartphone.jpg", "smartphone,mobile,android,flagship", true);

                createProduct(electronics, "Wireless Headphones", "wireless-headphones",
                    "Premium noise-canceling wireless headphones", new BigDecimal("15999"), 40,
                    "/images/products/headphones.jpg", "headphones,wireless,audio,music", true);

                createProduct(electronics, "Laptop Gaming Edition", "laptop-gaming",
                    "High-performance gaming laptop with dedicated graphics", new BigDecimal("89999"), 15,
                    "/images/products/laptop.jpg", "laptop,gaming,computer,performance", true);

                createProduct(electronics, "Smart Watch", "smart-watch",
                    "Fitness tracking smartwatch with heart rate monitor", new BigDecimal("12999"), 30,
                    "/images/products/smartwatch.jpg", "smartwatch,fitness,health,wearable", false);

                createProduct(electronics, "Bluetooth Speaker", "bluetooth-speaker",
                    "Portable waterproof Bluetooth speaker", new BigDecimal("4999"), 50,
                    "/images/products/speaker.jpg", "speaker,bluetooth,portable,music", false);
            }

            // Fashion products
            Category fashion = findCategoryBySlug(categories, "fashion");
            if (fashion != null) {
                createProduct(fashion, "Casual T-Shirt", "casual-tshirt",
                    "Comfortable cotton casual t-shirt for everyday wear", new BigDecimal("799"), 100,
                    "/images/products/tshirt.jpg", "tshirt,casual,cotton,comfortable", false);

                createProduct(fashion, "Formal Shirt", "formal-shirt",
                    "Professional formal shirt for office wear", new BigDecimal("1499"), 60,
                    "/images/products/formal-shirt.jpg", "shirt,formal,office,professional", false);

                createProduct(fashion, "Jeans", "denim-jeans",
                    "Classic denim jeans with perfect fit", new BigDecimal("2499"), 80,
                    "/images/products/jeans.jpg", "jeans,denim,casual,fashion", true);

                createProduct(fashion, "Sneakers", "sports-sneakers",
                    "Comfortable sports sneakers for active lifestyle", new BigDecimal("3999"), 45,
                    "/images/products/sneakers.jpg", "sneakers,sports,shoes,comfortable", false);
            }

            // Home & Kitchen products
            Category homeKitchen = findCategoryBySlug(categories, "home-kitchen");
            if (homeKitchen != null) {
                createProduct(homeKitchen, "Coffee Maker", "coffee-maker",
                    "Automatic drip coffee maker with programmable timer", new BigDecimal("8999"), 20,
                    "/images/products/coffee-maker.jpg", "coffee,maker,kitchen,appliance", true);

                createProduct(homeKitchen, "Non-Stick Pan Set", "nonstick-pan-set",
                    "5-piece non-stick cookware set", new BigDecimal("3499"), 35,
                    "/images/products/pan-set.jpg", "cookware,nonstick,kitchen,cooking", false);

                createProduct(homeKitchen, "Air Fryer", "air-fryer",
                    "Healthy oil-free air fryer with digital controls", new BigDecimal("12999"), 25,
                    "/images/products/air-fryer.jpg", "airfryer,healthy,cooking,appliance", true);
            }

            // Beauty & Health products
            Category beautyHealth = findCategoryBySlug(categories, "beauty-health");
            if (beautyHealth != null) {
                createProduct(beautyHealth, "Vitamin C Serum", "vitamin-c-serum",
                    "Anti-aging vitamin C serum for glowing skin", new BigDecimal("1299"), 75,
                    "/images/products/serum.jpg", "skincare,vitamin-c,serum,beauty", false);

                createProduct(beautyHealth, "Protein Powder", "whey-protein",
                    "Premium whey protein powder for muscle building", new BigDecimal("2999"), 40,
                    "/images/products/protein.jpg", "protein,fitness,supplement,health", true);
            }

            // Sports & Fitness products
            Category sportsFitness = findCategoryBySlug(categories, "sports-fitness");
            if (sportsFitness != null) {
                createProduct(sportsFitness, "Yoga Mat", "yoga-mat",
                    "Non-slip yoga mat for comfortable workouts", new BigDecimal("1599"), 60,
                    "/images/products/yoga-mat.jpg", "yoga,mat,fitness,exercise", false);

                createProduct(sportsFitness, "Dumbbells Set", "adjustable-dumbbells",
                    "Adjustable dumbbells set for home gym", new BigDecimal("8999"), 20,
                    "/images/products/dumbbells.jpg", "dumbbells,fitness,gym,strength", true);
            }

            // Books & Media products
            Category booksMedia = findCategoryBySlug(categories, "books-media");
            if (booksMedia != null) {
                createProduct(booksMedia, "Programming Book", "programming-guide",
                    "Complete guide to modern programming languages", new BigDecimal("899"), 100,
                    "/images/products/book.jpg", "book,programming,learning,education", false);
            }

            // Toys & Games products
            Category toysGames = findCategoryBySlug(categories, "toys-games");
            if (toysGames != null) {
                createProduct(toysGames, "Board Game", "strategy-board-game",
                    "Strategic board game for family entertainment", new BigDecimal("1799"), 30,
                    "/images/products/board-game.jpg", "boardgame,strategy,family,entertainment", false);

                createProduct(toysGames, "Building Blocks", "building-blocks",
                    "Creative building blocks set for kids", new BigDecimal("2499"), 50,
                    "/images/products/blocks.jpg", "toys,blocks,creative,kids", true);
            }

            logger.info("Products created successfully!");
        }
    }

    private Category findCategoryBySlug(List<Category> categories, String slug) {
        return categories.stream()
                .filter(cat -> slug.equals(cat.getSlug()))
                .findFirst()
                .orElse(null);
    }

    private void createProduct(Category category, String name, String slug, String description, 
                              BigDecimal price, int stock, String imageUrl, String tags, boolean featured) {
        Product product = new Product();
        product.setCategory(category);
        product.setName(name);
        product.setSlug(slug);
        product.setDescription(description);
        product.setPrice(price);
        product.setStockQuantity(stock);
        product.setImageUrl(imageUrl);
        product.setTags(tags);
        product.setIsFeatured(featured);
        product.setIsActive(true);

        productRepository.save(product);
    }
}
