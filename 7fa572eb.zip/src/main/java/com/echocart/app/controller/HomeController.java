package com.echocart.app.controller;

import com.echocart.app.entity.Category;
import com.echocart.app.entity.Product;
import com.echocart.app.entity.User;
import com.echocart.app.service.CatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
public class HomeController {

    private final CatalogService catalogService;

    @Autowired
    public HomeController(CatalogService catalogService) {
        this.catalogService = catalogService;
    }

    @GetMapping({"/", "/home"})
    public String home(Model model, @AuthenticationPrincipal User user) {
        List<Product> featuredProducts = catalogService.getFeaturedProducts();
        model.addAttribute("featuredProducts", featuredProducts);

        List<Category> categories = catalogService.getAllCategories();
        model.addAttribute("categories", categories);

        return "home";
    }

    @GetMapping("/categories")
    public String categories(Model model) {
        List<Category> categories = catalogService.getAllCategories();
        model.addAttribute("categories", categories);
        return "categories";
    }
}
