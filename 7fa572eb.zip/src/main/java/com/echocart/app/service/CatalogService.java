package com.echocart.app.service;

import com.echocart.app.entity.Category;
import com.echocart.app.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;

public interface CatalogService {
    List<Category> getAllCategories();
    Optional<Category> getCategoryBySlug(String slug);
    Category saveCategory(Category category);
    List<Product> getAllProducts();
    Page<Product> getProducts(Pageable pageable);
    Optional<Product> getProductBySlug(String slug);
    List<Product> getProductsByCategory(Category category);
    List<Product> getFeaturedProducts();
    Page<Product> searchProducts(String keyword, Pageable pageable);
    Product saveProduct(Product product);
    void deleteProduct(Long id);
    boolean existsBySlug(String slug);
}
