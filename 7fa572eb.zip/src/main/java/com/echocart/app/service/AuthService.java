package com.echocart.app.service;

import com.echocart.app.dto.UserRegistrationDto;
import com.echocart.app.entity.User;

public interface AuthService {
    User registerUser(UserRegistrationDto registrationDto);
    User authenticateUser(String identifier, String password);
    boolean isUsernameAvailable(String username);
    boolean isEmailAvailable(String email);
    boolean isPhoneNumberAvailable(String phoneNumber);
    void validateRegistrationData(UserRegistrationDto registrationDto);
}
