package com.echocart.app.repository;

import com.echocart.app.entity.Order;
import com.echocart.app.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    Optional<Order> findByOrderNumber(String orderNumber);
    List<Order> findByUser(User user);
    Page<Order> findByUser(User user, Pageable pageable);
    List<Order> findByUserOrderByPlacedAtDesc(User user);
    Page<Order> findByUserOrderByPlacedAtDesc(User user, Pageable pageable);
    boolean existsByOrderNumber(String orderNumber);
}
