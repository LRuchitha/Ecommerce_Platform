// EchoCart Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize cart functionality
    initializeCart();

    // Initialize wishlist functionality
    initializeWishlist();

    // Initialize search functionality
    initializeSearch();

    // Initialize quantity controls
    initializeQuantityControls();

    // Auto-hide flash messages
    autoHideFlashMessages();

    console.log('EchoCart initialized successfully!');
}

// Cart functionality
function initializeCart() {
    // Add to cart buttons
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            const quantity = this.dataset.quantity || 1;
            addToCart(productId, quantity);
        });
    });

    // Remove from cart buttons
    document.querySelectorAll('.remove-from-cart-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const cartItemId = this.dataset.cartItemId;
            removeFromCart(cartItemId);
        });
    });

    // Update cart quantity buttons
    document.querySelectorAll('.update-cart-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const cartItemId = this.dataset.cartItemId;
            const quantity = this.closest('.quantity-control').querySelector('input[type="number"]').value;
            updateCartQuantity(cartItemId, quantity);
        });
    });
}

// Wishlist functionality
function initializeWishlist() {
    document.querySelectorAll('.wishlist-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            const action = this.dataset.action; // 'add' or 'remove'

            if (action === 'add') {
                addToWishlist(productId);
            } else {
                removeFromWishlist(productId);
            }
        });
    });
}

// Search functionality
function initializeSearch() {
    const searchForm = document.querySelector('form[action*="search"]');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            const searchInput = this.querySelector('input[name="q"]');
            if (!searchInput.value.trim()) {
                e.preventDefault();
                showAlert('Please enter a search term', 'warning');
            }
        });
    }
}

// Quantity controls
function initializeQuantityControls() {
    document.querySelectorAll('.quantity-control').forEach(control => {
        const decreaseBtn = control.querySelector('.quantity-decrease');
        const increaseBtn = control.querySelector('.quantity-increase');
        const input = control.querySelector('input[type="number"]');

        if (decreaseBtn) {
            decreaseBtn.addEventListener('click', function() {
                const current = parseInt(input.value) || 1;
                if (current > 1) {
                    input.value = current - 1;
                    input.dispatchEvent(new Event('change'));
                }
            });
        }

        if (increaseBtn) {
            increaseBtn.addEventListener('click', function() {
                const current = parseInt(input.value) || 1;
                const max = parseInt(input.max) || 999;
                if (current < max) {
                    input.value = current + 1;
                    input.dispatchEvent(new Event('change'));
                }
            });
        }
    });
}

// Auto-hide flash messages
function autoHideFlashMessages() {
    setTimeout(function() {
        const alerts = document.querySelectorAll('#flash-messages .alert');
        alerts.forEach(alert => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            bsAlert.close();
        });
    }, 5000);
}

// Cart API calls
function addToCart(productId, quantity = 1) {
    showLoading('Adding to cart...');

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            productId: parseInt(productId),
            quantity: parseInt(quantity)
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert(data.message, 'success');
            updateCartBadge(data.cartItemCount);

            // Update button state if on product page
            const addButton = document.querySelector(`[data-product-id="${productId}"]`);
            if (addButton) {
                addButton.innerHTML = '<i class="bi bi-check-circle me-1"></i>Added to Cart';
                addButton.classList.remove('btn-primary');
                addButton.classList.add('btn-success');
                setTimeout(() => {
                    addButton.innerHTML = '<i class="bi bi-cart-plus me-1"></i>Add to Cart';
                    addButton.classList.remove('btn-success');
                    addButton.classList.add('btn-primary');
                }, 2000);
            }
        } else {
            showAlert(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showAlert('Failed to add item to cart', 'error');
        console.error('Error:', error);
    });
}

function removeFromCart(cartItemId) {
    showLoading('Removing from cart...');

    fetch(`/cart/remove/${cartItemId}`, {
        method: 'DELETE',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert(data.message, 'success');
            updateCartBadge(data.cartItemCount);

            // Remove item from DOM
            const cartItem = document.querySelector(`[data-cart-item-id="${cartItemId}"]`);
            if (cartItem) {
                cartItem.remove();
            }

            // Update cart total if displayed
            if (data.cartTotal !== undefined) {
                updateCartTotal(data.cartTotal);
            }

            // Reload page if cart is now empty
            if (data.cartItemCount === 0 && window.location.pathname === '/cart') {
                location.reload();
            }
        } else {
            showAlert(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showAlert('Failed to remove item from cart', 'error');
        console.error('Error:', error);
    });
}

function updateCartQuantity(cartItemId, quantity) {
    showLoading('Updating cart...');

    fetch(`/cart/update/${cartItemId}?quantity=${quantity}`, {
        method: 'PUT',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert(data.message, 'success');
            updateCartBadge(data.cartItemCount);

            // Update line total if displayed
            if (data.cartItem) {
                const lineTotalElement = document.querySelector(`#line-total-${cartItemId}`);
                if (lineTotalElement) {
                    lineTotalElement.textContent = '₹' + data.cartItem.lineTotal;
                }
            }

            // Update cart total if displayed
            if (data.cartTotal !== undefined) {
                updateCartTotal(data.cartTotal);
            }
        } else {
            showAlert(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showAlert('Failed to update cart', 'error');
        console.error('Error:', error);
    });
}

// Wishlist API calls
function addToWishlist(productId) {
    showLoading('Adding to wishlist...');

    fetch(`/wishlist/add/${productId}`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert(data.message, 'success');
            updateWishlistBadge(data.wishlistItemCount);

            // Update wishlist button
            const wishlistBtn = document.querySelector(`[data-product-id="${productId}"][data-action="add"]`);
            if (wishlistBtn) {
                wishlistBtn.innerHTML = '<i class="bi bi-heart-fill me-1"></i>Remove from Wishlist';
                wishlistBtn.dataset.action = 'remove';
                wishlistBtn.classList.remove('btn-outline-danger');
                wishlistBtn.classList.add('btn-danger');
            }
        } else {
            showAlert(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showAlert('Failed to add to wishlist', 'error');
        console.error('Error:', error);
    });
}

function removeFromWishlist(productId) {
    showLoading('Removing from wishlist...');

    fetch(`/wishlist/remove/${productId}`, {
        method: 'DELETE',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showAlert(data.message, 'success');
            updateWishlistBadge(data.wishlistItemCount);

            // Update wishlist button
            const wishlistBtn = document.querySelector(`[data-product-id="${productId}"][data-action="remove"]`);
            if (wishlistBtn) {
                wishlistBtn.innerHTML = '<i class="bi bi-heart me-1"></i>Add to Wishlist';
                wishlistBtn.dataset.action = 'add';
                wishlistBtn.classList.remove('btn-danger');
                wishlistBtn.classList.add('btn-outline-danger');
            }

            // Remove from wishlist page if applicable
            if (window.location.pathname === '/wishlist') {
                const wishlistItem = document.querySelector(`[data-product-id="${productId}"]`).closest('.wishlist-item');
                if (wishlistItem) {
                    wishlistItem.remove();
                }
            }
        } else {
            showAlert(data.message, 'error');
        }
    })
    .catch(error => {
        hideLoading();
        showAlert('Failed to remove from wishlist', 'error');
        console.error('Error:', error);
    });
}

// Utility functions
function updateCartBadge(count) {
    const badge = document.querySelector('.navbar .badge');
    if (badge && count !== undefined) {
        if (count > 0) {
            badge.textContent = count;
            badge.style.display = 'inline';
        } else {
            badge.style.display = 'none';
        }
    }
}

function updateWishlistBadge(count) {
    const badge = document.querySelector('.navbar .badge');
    if (badge && count !== undefined) {
        if (count > 0) {
            badge.textContent = count;
            badge.style.display = 'inline';
        } else {
            badge.style.display = 'none';
        }
    }
}

function updateCartTotal(total) {
    const totalElements = document.querySelectorAll('.cart-total');
    totalElements.forEach(element => {
        element.textContent = '₹' + total;
    });
}

function showAlert(message, type = 'info') {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.dynamic-alert');
    existingAlerts.forEach(alert => alert.remove());

    // Create new alert
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show dynamic-alert`;
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '20px';
    alertDiv.style.right = '20px';
    alertDiv.style.zIndex = '9999';
    alertDiv.style.minWidth = '300px';

    const icon = type === 'success' ? 'check-circle' : 
                type === 'error' ? 'exclamation-triangle' : 
                type === 'warning' ? 'exclamation-triangle' : 'info-circle';

    alertDiv.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.body.appendChild(alertDiv);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alertDiv);
            bsAlert.close();
        }
    }, 5000);
}

function showLoading(message = 'Loading...') {
    // Remove existing loading
    hideLoading();

    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'loading-overlay';
    loadingDiv.innerHTML = `
        <div class="loading-content">
            <div class="loading"></div>
            <div class="mt-2">${message}</div>
        </div>
    `;

    loadingDiv.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        color: white;
        text-align: center;
    `;

    document.body.appendChild(loadingDiv);
}

function hideLoading() {
    const loadingDiv = document.getElementById('loading-overlay');
    if (loadingDiv) {
        loadingDiv.remove();
    }
}

// Form validation helpers
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('is-invalid');
            isValid = false;
        } else {
            input.classList.remove('is-invalid');
        }
    });

    return isValid;
}

// Export functions for global use
window.EchoCart = {
    addToCart,
    removeFromCart,
    updateCartQuantity,
    addToWishlist,
    removeFromWishlist,
    showAlert,
    showLoading,
    hideLoading,
    validateForm
};
